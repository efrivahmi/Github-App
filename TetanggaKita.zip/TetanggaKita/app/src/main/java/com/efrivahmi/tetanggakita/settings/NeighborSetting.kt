package com.efrivahmi.tetanggakita.settings

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.efrivahmi.tetanggakita.databinding.ActivityNeighborSettingBinding
import com.efrivahmi.tetanggakita.main.MainActivity

class NeighborSetting : AppCompatActivity() {
    private val viewModel by viewModels<SettingViewModel> { SettingViewModel.Factory(Preferences(this)) }
    private lateinit var binding: ActivityNeighborSettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNeighborSettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupActionBar()
        observeTheme()
        setupThemeChangeListener()
    }

    private fun setupActionBar() {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun observeTheme() {
        viewModel.getTheme().observe(this) { isDarkMode ->
            val themeText = if (isDarkMode) "Dark_Theme" else "Light_Theme"
            binding.theme.text = themeText
            AppCompatDelegate.setDefaultNightMode(if (isDarkMode) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
            binding.theme.isChecked = isDarkMode
        }
    }

    private fun setupThemeChangeListener() {
        binding.theme.setOnCheckedChangeListener { _, isChecked ->
            viewModel.saveTheme(isChecked)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("theme_changed", false)
                startActivity(intent)
                finish()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
