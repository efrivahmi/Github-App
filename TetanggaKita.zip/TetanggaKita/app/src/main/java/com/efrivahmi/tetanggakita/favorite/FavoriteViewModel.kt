package com.efrivahmi.tetanggakita.favorite

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.efrivahmi.tetanggakita.data.dao.DataBaseConfigure
import com.efrivahmi.tetanggakita.data.model.ResponseUser

class FavoriteViewModel(private val dataBaseConfigure: DataBaseConfigure) : ViewModel() {
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean>
        get() = _isLoading

    fun getGithubFavorite(): LiveData<List<ResponseUser.Item>> {
        val favoriteList = MutableLiveData<List<ResponseUser.Item>>()
        setLoading(true)
        dataBaseConfigure.daoNeighbor.loadAll().observeForever { favorites ->
            favoriteList.postValue(favorites)
            setLoading(false)
        }
        return favoriteList
    }

    private fun setLoading(isLoading: Boolean) {
        _isLoading.value = isLoading
    }

    class Factory(private val dbc: DataBaseConfigure) : ViewModelProvider.NewInstanceFactory() {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FavoriteViewModel(dbc) as T
        }
    }
}