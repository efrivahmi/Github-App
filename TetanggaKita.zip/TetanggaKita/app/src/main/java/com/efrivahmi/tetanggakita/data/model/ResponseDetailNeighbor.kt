package com.efrivahmi.tetanggakita.data.model

data class ResponseDetailNeighbor(
    val avatar_url: String,
    val followers: Int,
    val following: Int,
    val id: Int,
    val login: String,
    val name: String,
)