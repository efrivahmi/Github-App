package com.efrivahmi.tetanggakita.data.service

import com.efrivahmi.tetanggakita.data.model.ResponseDetailNeighbor
import com.efrivahmi.tetanggakita.data.model.ResponseUser
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.QueryMap


interface ServiceGithub {

    @GET("search/users")
    suspend fun searchUsers(@Query("q") query: String, @Query("per_page") perPage: Int = 100): Response<ResponseUser>

    @GET("users/{username}")
    suspend fun getUsersDetail(@Path("username")username: String): ResponseDetailNeighbor

    @GET("users/{username}/followers")
    suspend fun getFollowers(@Path("username")username: String): MutableList<ResponseUser.Item>

    @GET("users/{username}/following")
    suspend fun getFollowing(@Path("username")username: String): MutableList<ResponseUser.Item>

    @JvmSuppressWildcards
    @GET("search/users")
    suspend fun searchUsersGithub(@QueryMap params: Map<String, Any>, @Query("per_page") perPage: Int = 20): Response<ResponseUser>
}
