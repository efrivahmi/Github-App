package com.efrivahmi.tetanggakita.favorite

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.efrivahmi.tetanggakita.data.dao.DataBaseConfigure
import com.efrivahmi.tetanggakita.data.model.ResponseUser
import com.efrivahmi.tetanggakita.databinding.ActivityFavoriteNeighborBinding
import com.efrivahmi.tetanggakita.detail.DetailNeighbor
import com.efrivahmi.tetanggakita.main.UserAdapter

class FavoriteNeighbor : AppCompatActivity() {
    private lateinit var binding: ActivityFavoriteNeighborBinding
    private val adapter by lazy {
        UserAdapter { userGithub ->
            Intent(this, DetailNeighbor::class.java).apply {
                putExtra("item", userGithub)
                startActivity(this)
            }
        }
    }
    private val dataBaseConfigure: DataBaseConfigure by lazy {
        DataBaseConfigure(this)
    }
    private val viewModel by viewModels<FavoriteViewModel> {
        FavoriteViewModel.Factory(dataBaseConfigure)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteNeighborBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        binding.rvFavorite.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@FavoriteNeighbor.adapter
        }

        viewModel.isLoading.observe(this) { isLoading ->
            binding.progressBar2.visibility = if (isLoading) View.VISIBLE else View.GONE
        }

        viewModel.getGithubFavorite().observe(this) { favorites ->
            adapter.setData(favorites as MutableList<ResponseUser.Item>)
        }
    }

    override fun onResume() {
        super.onResume()

        viewModel.getGithubFavorite().observe(this) { favorites ->
            adapter.setData(favorites as MutableList<ResponseUser.Item>)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> finish()
        }
        return super.onOptionsItemSelected(item)
    }
}
