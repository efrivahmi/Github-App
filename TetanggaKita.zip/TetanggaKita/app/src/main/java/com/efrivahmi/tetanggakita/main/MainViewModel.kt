package com.efrivahmi.tetanggakita.main

import android.util.Log
import androidx.lifecycle.*
import com.efrivahmi.tetanggakita.data.service.ApiGithub
import com.efrivahmi.tetanggakita.settings.Preferences
import com.efrivahmi.tetanggakita.utils.Result
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch

class MainViewModel(private val preferences: Preferences): ViewModel() {
    val resultUserNeighbor = MutableLiveData<Result>()

    fun getTheme() = preferences.getThemeSetting().asLiveData()

    fun getNeighbor() {
        viewModelScope.launch {
            flow {
                val response = ApiGithub.serviceGithub.searchUsers("efri", 100)

                emit(response.body()?.items)
            }.onStart {
                resultUserNeighbor.value = Result.Loading(true)
            }.onCompletion {
                resultUserNeighbor.value = Result.Loading(false)
            }.catch {
                Log.e("error", it.message.toString())
                it.printStackTrace()
                resultUserNeighbor.value = Result.Error(it)
            }.collect { items ->
                resultUserNeighbor.value = Result.Success(items)
            }
        }
    }

    fun getUsersGithub(query: String) {
        viewModelScope.launch {
            flow {
                val query = "$query in:login"
                val response = ApiGithub.serviceGithub.searchUsersGithub(mapOf("q" to query, "per_page" to 20))

                emit(response.body()?.items)
            }.onStart {
                resultUserNeighbor.value = Result.Loading(true)
            }.onCompletion {
                resultUserNeighbor.value = Result.Loading(false)
            }.catch {
                Log.e("error", it.message.toString())
                it.printStackTrace()
                resultUserNeighbor.value = Result.Error(it)
            }.collect { items ->
                resultUserNeighbor.value = Result.Success(items)
            }
        }
    }
    class Factory (private val preferences: Preferences): ViewModelProvider.NewInstanceFactory(){
        override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(preferences) as T
    }
}



