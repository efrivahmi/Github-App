package com.efrivahmi.tetanggakita.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.efrivahmi.tetanggakita.data.model.ResponseUser

@Dao
interface DaoNeighbor {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(userGithub: ResponseUser.Item)

    @Query("SELECT * FROM userGithub")
    fun loadAll(): LiveData<MutableList<ResponseUser.Item>>

    @Query("SELECT * FROM userGithub WHERE id LIKE :id LIMIT 2")
    fun findById (id: Int): ResponseUser.Item

    @Delete
    fun delete (userGithub: ResponseUser.Item)
}