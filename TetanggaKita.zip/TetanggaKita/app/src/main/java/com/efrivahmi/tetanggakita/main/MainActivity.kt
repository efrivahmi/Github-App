package com.efrivahmi.tetanggakita.main

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SearchView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.efrivahmi.tetanggakita.R
import com.efrivahmi.tetanggakita.data.model.ResponseUser
import com.efrivahmi.tetanggakita.databinding.ActivityMainBinding
import com.efrivahmi.tetanggakita.detail.DetailNeighbor
import com.efrivahmi.tetanggakita.favorite.FavoriteNeighbor
import com.efrivahmi.tetanggakita.settings.NeighborSetting
import com.efrivahmi.tetanggakita.settings.Preferences

class MainActivity : AppCompatActivity() {
    private val adapter by lazy {
        UserAdapter {userGithub ->
            Intent(this, DetailNeighbor::class.java).apply {
                putExtra("item", userGithub)
                startActivity(this)
            }
            Toast.makeText(this, "You have chosen ${userGithub.login} ", Toast.LENGTH_SHORT).show()
        }
    }

    private val viewModel: MainViewModel by viewModels {
        MainViewModel.Factory(Preferences(this))
    }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel.getTheme().observe(this){
            if (it) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

        }

        binding.rvContact.adapter = adapter
        binding.rvContact.layoutManager = LinearLayoutManager(this)
        binding.rvContact.setHasFixedSize(true)

        binding.search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (query != null) {
                    viewModel.getUsersGithub(query)
                }
                return true
            }


            override fun onQueryTextChange(p0: String?): Boolean = false
        })

        viewModel.resultUserNeighbor.observe(this) { result ->
            when (result) {
                is com.efrivahmi.tetanggakita.utils.Result.Success<*> -> adapter.setData(result.data as MutableList<ResponseUser.Item>)
                is com.efrivahmi.tetanggakita.utils.Result.Error -> Toast.makeText(this, result.exception.message.toString(), Toast.LENGTH_SHORT).show()
                is com.efrivahmi.tetanggakita.utils.Result.Loading -> binding.progressBar.isVisible = result.isLoading
            }
        }
        viewModel.getNeighbor()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.neighbor_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_favorite -> {
                Intent(this,FavoriteNeighbor::class.java).apply {
                    startActivity(this)
                }
                Toast.makeText(this, "Here is your favorite profile", Toast.LENGTH_SHORT).show()
            }
            R.id.theme -> {
                Intent(this,NeighborSetting::class.java).apply {
                    startActivity(this)
                }
            }
        }
        return super.onOptionsItemSelected(item)
    }
}
