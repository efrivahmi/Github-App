package com.efrivahmi.tetanggakita.data.service

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import java.util.concurrent.TimeUnit

object ApiGithub {
    private val authInterceptor = Interceptor { chain ->
        val req = chain.request()
        val requestHeaders = req.newBuilder()
            .addHeader("Authorization", "Bearer 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")
            .build()
        chain.proceed(requestHeaders)
    }

    private val okhttp = OkHttpClient.Builder()
        .apply {
            val loggingInterceptor = HttpLoggingInterceptor()
            loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY
            addInterceptor(loggingInterceptor)
        }
        .addInterceptor(authInterceptor)
        .readTimeout(50, TimeUnit.SECONDS)
        .writeTimeout(400, TimeUnit.SECONDS)
        .connectTimeout(50, TimeUnit.SECONDS)
        .build()
    private val retrofit = Retrofit.Builder()
        .baseUrl("https://api.github.com/")
        .client(okhttp)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val serviceGithub = retrofit.create<ServiceGithub>()
}

