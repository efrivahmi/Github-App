package com.efrivahmi.tetanggakita.detail

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.efrivahmi.tetanggakita.data.dao.DataBaseConfigure
import com.efrivahmi.tetanggakita.data.model.ResponseUser
import com.efrivahmi.tetanggakita.data.service.ApiGithub
import com.efrivahmi.tetanggakita.utils.Result
import kotlinx.coroutines.launch


class DetailViewModel(private val dbc: DataBaseConfigure) : ViewModel() {
    val resultUser = MutableLiveData<Result>()
    val resultUserFollowers = MutableLiveData<Result>()
    val resultUserFollowing = MutableLiveData<Result>()
    val resultSuccessFavorite = MutableLiveData<Boolean>()
    val resultDeleteFavorite = MutableLiveData<Boolean>()

    var isFavorite = false

    fun setFavorite(item: ResponseUser.Item?){
        viewModelScope.launch {
            item?.let {
                if (isFavorite){
                    dbc.daoNeighbor.delete(item)
                    resultDeleteFavorite.value= true
                }else{
                    dbc.daoNeighbor.insert(item)
                    resultSuccessFavorite.value = true
                }
            }
            isFavorite = !isFavorite
        }
        }

    fun findFavorite(id: Int, listenFavorite: () -> Unit){
        viewModelScope.launch {
            val userGithub = dbc.daoNeighbor.findById(id)
            if (userGithub != null){
                isFavorite = true
                listenFavorite()
            }
        }
    }
    fun getUsersDetail(username: String) {
        viewModelScope.launch {
            try {
                resultUser.value = Result.Loading(true)
                val response = ApiGithub.serviceGithub.getUsersDetail(username)
                resultUser.value = Result.Success(response)
            } catch (e: Exception) {
                Log.e("error", e.message.toString())
                e.printStackTrace()
                resultUser.value = Result.Error(e)
            } finally {
                resultUser.value = Result.Loading(false)
            }
        }
    }

    fun getFollowers(username: String) {
        viewModelScope.launch {
            try {
                resultUserFollowers.value = Result.Loading(true)
                val response = ApiGithub.serviceGithub.getFollowers(username)
                resultUserFollowers.value = Result.Success(response)
            } catch (e: Exception) {
                Log.e("error", e.message.toString())
                e.printStackTrace()
                resultUserFollowers.value = Result.Error(e)
            } finally {
                resultUserFollowers.value = Result.Loading(false)
            }
        }
    }

    fun getFollowing(username: String) {
        viewModelScope.launch {
            try {
                resultUserFollowing.value = Result.Loading(true)
                val response = ApiGithub.serviceGithub.getFollowing(username)
                resultUserFollowing.value = Result.Success(response)
            } catch (e: Exception) {
                Log.e("error", e.message.toString())
                e.printStackTrace()
                resultUserFollowing.value = Result.Error(e)
            } finally {
                resultUserFollowing.value = Result.Loading(false)
            }
        }
    }
    class Factory(private val dbc: DataBaseConfigure): ViewModelProvider.NewInstanceFactory(){
        override fun <T : ViewModel> create(modelClass: Class<T>): T = DetailViewModel(dbc) as T
        }
    }

