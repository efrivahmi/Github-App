package com.efrivahmi.tetanggakita.data.dao

import android.content.Context
import androidx.room.Room

class DataBaseConfigure(private val context: Context) {
    private val dbc = Room.databaseBuilder(context,DataBase::class.java, "neighbor-github.dbc")
        .allowMainThreadQueries()
        .build()
    val daoNeighbor = dbc.daoNeighbor()
}