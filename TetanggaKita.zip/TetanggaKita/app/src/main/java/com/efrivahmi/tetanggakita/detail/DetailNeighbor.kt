package com.efrivahmi.tetanggakita.detail

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.ColorRes
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import coil.load
import coil.transform.CircleCropTransformation
import com.efrivahmi.tetanggakita.R
import com.efrivahmi.tetanggakita.data.dao.DataBaseConfigure
import com.efrivahmi.tetanggakita.data.model.ResponseDetailNeighbor
import com.efrivahmi.tetanggakita.data.model.ResponseUser
import com.efrivahmi.tetanggakita.databinding.ActivityDetailNeighborBinding
import com.efrivahmi.tetanggakita.detail.followersing.FollowersingFragment
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class DetailNeighbor : AppCompatActivity() {
    private lateinit var binding: ActivityDetailNeighborBinding
    private val viewModel by viewModels<DetailViewModel> {
        DetailViewModel.Factory(DataBaseConfigure(this))
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailNeighborBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val item = intent.getParcelableExtra<ResponseUser.Item>("item")

        viewModel.resultUser.observe(this) {
            when (it) {
                is com.efrivahmi.tetanggakita.utils.Result.Success<*> -> {
                    val user = it.data as ResponseDetailNeighbor
                    binding.image.load(user.avatar_url) {
                        transformations(CircleCropTransformation())
                    }
                    binding.nama.text = user.name
                    binding.username.text = user.login
                    binding.followers.text = "${user.followers} Followers"
                    binding.following.text = "${user.following} Following"
                }
                is com.efrivahmi.tetanggakita.utils.Result.Error -> {
                    Toast.makeText(this, it.exception.message.toString(), Toast.LENGTH_SHORT).show()
                }
                is com.efrivahmi.tetanggakita.utils.Result.Loading -> {
                    binding.Progress.isVisible = it.isLoading
                }
            }
        }

        viewModel.getUsersDetail(item?.login ?: "")
        val fragments = mutableListOf<Fragment>(
            FollowersingFragment.newInstance(FollowersingFragment.Followers),
            FollowersingFragment.newInstance(FollowersingFragment.Following)
        )
        val titleFragments = mutableListOf(
            getString(R.string.followers),
            getString(R.string.following)
        )
        val adapter = DetailAdapter(this, fragments)
        binding.pager.adapter = adapter
        TabLayoutMediator(binding.tabs, binding.pager) { tab, position ->
            tab.text = titleFragments[position]
        }.attach()



        binding.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == null) {
                    viewModel.getFollowers(item?.login ?: "")
                } else {
                    viewModel.getFollowing(item?.login ?: "")
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}

            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        viewModel.getFollowers(item?.login ?: "")
        binding.btnFav.setOnClickListener {
            viewModel.setFavorite(item)
            Toast.makeText(this, "${if (viewModel.isFavorite) "Added to your favorites" else "Deleted from your favorites"} ", Toast.LENGTH_SHORT).show()
        }

        viewModel.findFavorite(item?.id ?: 0) {
            binding.btnFav.changeIconColor(R.color.blue)
        }
        viewModel.resultSuccessFavorite.observe(this){
            binding.btnFav.changeIconColor(R.color.blue)
        }
        viewModel.resultDeleteFavorite.observe(this){
            binding.btnFav.changeIconColor(R.color.white)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun FloatingActionButton.changeIconColor(@ColorRes color: Int) {
        val color = ContextCompat.getColor(this.context, color)
        imageTintList = ColorStateList.valueOf(color)
    }
}