package com.efrivahmi.tetanggakita.detail.followersing

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.efrivahmi.tetanggakita.data.model.ResponseUser
import com.efrivahmi.tetanggakita.databinding.FragmentFollowersingBinding
import com.efrivahmi.tetanggakita.detail.DetailViewModel
import com.efrivahmi.tetanggakita.main.UserAdapter
import com.efrivahmi.tetanggakita.utils.Result

class FollowersingFragment : Fragment() {
    private var binding: FragmentFollowersingBinding? = null
    private val adapter by lazy {
        UserAdapter {

        }
    }
    private val viewModel by activityViewModels<DetailViewModel>()
    var type = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentFollowersingBinding.inflate(layoutInflater)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.rvfollowersing?.apply {
            layoutManager = LinearLayoutManager(requireActivity())
            setHasFixedSize(true)
            adapter = this@FollowersingFragment.adapter
        }
        when (type) {
            Followers -> {
                viewModel.resultUserFollowers.observe(viewLifecycleOwner,this::manageResultUserFollowers)
            }
            Following -> {
                viewModel.resultUserFollowing.observe(viewLifecycleOwner,this::manageResultUserFollowers)
            }
        }



    }

    private fun manageResultUserFollowers(state: Result) {
        when (state) {
            is Result.Success<*> -> {
                adapter.setData(state.data as MutableList<ResponseUser.Item>)
            }
            is Result.Error -> {
                Toast.makeText(requireActivity(),state.exception.message.toString(), Toast.LENGTH_SHORT).show()
            }
            is Result.Loading -> {
                binding?.progress?.isVisible = state.isLoading
            }
        }
    }

    companion object {
        const val Followers = 100
        const val Following = 101

        fun newInstance(type: Int) =
            FollowersingFragment()
                .apply {
                    this.type = type
                }

    }
}
